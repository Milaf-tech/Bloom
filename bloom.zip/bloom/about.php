<?php $page = "about"; include("include/header.php"); ?>


		<section class="page-content" id="page-content">
			<h2 class="title">About Bloom</h2>
			<hr>
			<h3 class="title">About us</h3>
			<p>
				Most people spend a lot of time searching for a high-level restaurant according to their desires wether they are citizen or visitors ,
				so our website saves your time to be able to search restaurant based on the category that you want and see all the restaurants  related to the category that you chose and their informatin so you can go to them , also you can see thier ratings and reviews
				  from customers and you can write your review.
			</p>

			<h3 class="title">Mission</h3>
			<p>
				Collects all of the Restaurants in the region in a single web site for easy access to users whether they were
				citizens or visitors and the ability to finding the best option and see the reviews related to it.
			</p>

			<h3 class="title">Vision</h3>
			<p>
				Helping People choose the right restaurant for them.
			</p>

			<h3 class="title">Contact information:</h3>
			<ul>
				<li><strong>Phone NO: </strong>996503206666</li>
				<li><strong>Email: </strong>bloom24@gmail.com</li>
				<li><strong>Riyadh-SA</strong></li>
			</ul>
		</section>

		<?php include("include/footer.php"); ?>