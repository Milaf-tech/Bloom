<?php

function loginAdmin($username, $password) {
    global $conn;
    global $error_msg;

    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    $sql = "SELECT * FROM `admin` WHERE username = '$username';";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $user = mysqli_fetch_assoc($result);
        if ($user['password'] == md5($password)) {
            return $user['id'];
        } else {
            $error_msg = "Username or password not matched." . md5('admin') . '|' . $password . '|' . $admin;
            return false;
        }
    }

    $error_msg = "Error, Can not login.";
    return false;
}

function addItem($category_id, $name, $location, $open_time, $description, $logo) {
    global $conn;
    global $error_msg;

    $category_id = mysqli_real_escape_string($conn, $category_id);
    $name = mysqli_real_escape_string($conn, $name);
    $location = mysqli_real_escape_string($conn, $location);
    $open_time = mysqli_real_escape_string($conn, $open_time);
    $description = mysqli_real_escape_string($conn, $description);
    $logo = mysqli_real_escape_string($conn, $logo);

    if (empty(trim($category_id)) || empty(trim($name)) || empty(trim($location)) || empty(trim($open_time))) {
        $error_msg = "Please, Provide all required item data.";
        return false;
    }

    $sql = "INSERT INTO `item` (category_id, name, location, open_time, description, logo) values ('$category_id', '$name', '$location', '$open_time', '$description', '$logo');";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        return mysqli_insert_id($conn);
    }

    $error_msg = "Error, Can not add Item.";
    return false;
}

function editItem($id, $category_id, $name, $location, $open_time, $description, $logo) {
    global $conn;
    global $error_msg;

    $id = mysqli_real_escape_string($conn, $id);
    $category_id = mysqli_real_escape_string($conn, $category_id);
    $name = mysqli_real_escape_string($conn, $name);
    $location = mysqli_real_escape_string($conn, $location);
    $open_time = mysqli_real_escape_string($conn, $open_time);
    $description = mysqli_real_escape_string($conn, $description);
    $logo = mysqli_real_escape_string($conn, $logo);

    if (empty(trim($id)) || empty(trim($category_id)) || empty(trim($name)) || empty(trim($location)) || empty(trim($open_time))) {
        $error_msg = "Please, Provide all required item data.";
        return false;
    }

    if (empty(trim($logo))) {
        $sql = "UPDATE `item` SET category_id = '$category_id', name = '$name', location = '$location', open_time = '$open_time', description = '$description' WHERE id = '$id';";
    } else {
        $sql = "UPDATE `item` SET category_id = '$category_id', name = '$name', location = '$location', open_time = '$open_time', description = '$description', logo = '$logo' WHERE id = '$id';";
    }

    $result = mysqli_query($conn, $sql);

    if ($result) {
        return true;
    }

    $error_msg = "Error, Can not edit item." . $sql;
    return false;
}

function deleteItem($id) {
    global $conn;
    global $error_msg;

    $id = mysqli_real_escape_string($conn, $id);

    $sql = "DELETE FROM `item` WHERE id = '$id';";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        return true;
    }

    $error_msg = "Error, Can not delete item." . $sql;
    return false;
}

function getItemInfo($id) {
    global $conn;
    global $error_msg;

    $id = mysqli_real_escape_string($conn, $id);

    $sql = "SELECT i.*, ROUND(AVG(r.rating), 1) AS `rating` FROM `item` i LEFT JOIN `review` r ON i.id = r.item_id WHERE i.id = '$id' GROUP BY i.id;";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $item = mysqli_fetch_assoc($result);

        if (empty(trim($item['logo']))) {
            $item['logo'] = "img/restaurant/04.jpg";
        } else {
            $item['logo'] = "data:image/jpeg;base64," . base64_encode($item['logo']);
        }

        return $item;
    }

    return false;
}

function getAllItems() {
    global $conn;
    global $error_msg;

    $sql = "SELECT i.*, ROUND(AVG(r.rating), 1) AS `rating` FROM `item` i LEFT JOIN `review` r ON i.id = r.item_id GROUP BY i.id;";
    $result = mysqli_query($conn, $sql);

    $items = array();

    if ($result && mysqli_num_rows($result) > 0) {
        $items = $result->fetch_all(MYSQLI_ASSOC);
       
        foreach ($items as $key => &$item) {
            if (empty(trim($item['logo']))) {
                $item['logo'] = "img/restaurant";
            } else {
                $item['logo'] = "data:image/jpeg;base64," . base64_encode($item['logo']);
            }
        }
    }

    return $items;
}

function getNewItems($limit) {
    global $conn;
    global $error_msg;

    $limit = mysqli_real_escape_string($conn, $limit);

    $sql = "SELECT i.*, ROUND(AVG(r.rating), 1) AS `rating` FROM `item` i LEFT JOIN `review` r ON i.id = r.item_id GROUP BY i.id ORDER BY i.id DESC LIMIT $limit;";
    $result = mysqli_query($conn, $sql);

    $items = array();

    if ($result && mysqli_num_rows($result) > 0) {
        $items = $result->fetch_all(MYSQLI_ASSOC);
       
        foreach ($items as $key => &$item) {
            if (empty(trim($item['logo']))) {
                $item['logo'] = "img/restaurant/04.jpg";
            } else {
                $item['logo'] = "data:image/jpeg;base64," . base64_encode($item['logo']);
            }
        }
    }

    return $items;
}


function getSearchItems($name) {
    global $conn;
    global $error_msg;

    $name = mysqli_real_escape_string($conn, $name);

    $sql = "SELECT i.*, ROUND(AVG(r.rating), 1) AS `rating` FROM `item` i LEFT JOIN `review` r ON i.id = r.item_id WHERE i.name LIKE '%$name%' GROUP BY i.id;";
    $result = mysqli_query($conn, $sql);

    $items = array();

    if ($result && mysqli_num_rows($result) > 0) {
        $items = $result->fetch_all(MYSQLI_ASSOC);
       
        foreach ($items as $key => &$item) {
            if (empty(trim($item['logo']))) {
                $item['logo'] = "img/restaurant/04.jpg";
            } else {
                $item['logo'] = "data:image/jpeg;base64," . base64_encode($item['logo']);
            }
        } 
    }

    return $items;
}

function getItemReviews($item_id) {
    global $conn;
    global $error_msg;

    $item_id = mysqli_real_escape_string($conn, $item_id);

    $sql = "SELECT * FROM `review` WHERE item_id = '$item_id';";
    $result = mysqli_query($conn, $sql);
    
    $reviews = array();

    if ($result && mysqli_num_rows($result) > 0) {     
        $reviews = $result->fetch_all(MYSQLI_ASSOC);
    } 

    return $reviews;
}


function addItemReview($item_id, $name, $rating, $body) {
    global $conn;
    global $error_msg;

    $item_id = mysqli_real_escape_string($conn, $item_id);
    $name = mysqli_real_escape_string($conn, $name);
    $rating = mysqli_real_escape_string($conn, $rating);
    $body = mysqli_real_escape_string($conn, $body);

    if (empty(trim($item_id)) || empty(trim($name)) || empty(trim($rating)) || empty(trim($body))) {
        $error_msg = "Please, Provide all required review data."  . $item_id . " | " . $name;
        return false;
    }

    $sql = "INSERT INTO `review` (item_id, name, rating, body) values ('$item_id', '$name', '$rating', '$body');";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        return mysqli_insert_id($conn);
    }

    $error_msg = "Error, Can not add review." . $conn->error;
    return false;
}