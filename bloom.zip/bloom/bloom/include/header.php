<?php
if (isset($_COOKIE['admin'])) {
    $admin = $_COOKIE['admin'];
}
$page_title = "";

if (isset($page)) {
    if ($page == 'home')
        $page_title = 'Home';
    else if ($page == 'about')
        $page_title = 'About';
    else if ($page == 'restaurant-cat')
        $page_title = 'Restaurants Categories';
    else if ($page == 'contact')
        $page_title = 'Contat Us';
    else if ($page == 'login')
        $page_title = 'Login';
    else if ($page == 'admin-page')
        $page_title = 'Admin Page';
    else if ($page == 'add-restaurant')
        $page_title = 'Add new restaurant';
    else if ($page == 'edit-restaurant')
        $page_title = 'Edit restaurant';
    else if ($page == 'restaurant-info')
        $page_title = 'Restaurant information page';
} else {
    $page = 'home';
}

?>

<!DOCTYPE html>
<html>

<head>
	<title>Bloom | <?php if (isset($page_title)) echo $page_title; ?></title>
	<link rel="shortcut icon" href="img/logoo.ico">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="./css/style.css" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script type="text/javascript" src="./js/javascript.js"></script>
</head>

<body>

	<div class="container">

		<header class="site-header">
			<section class="top-header">
				<div class="logo"><img src="img/logo.png" alt=""></div>
				<div class="search">
					<form action="restaurant.php" method="get">
						<input type="text" value="" id="search" name="search">
						<input type="submit" id="searchsubmit" value="Search">
					</form>
				</div>
				<div class="top-header-right menu-content">                
                    <ul class="user_menu">
                    <?php if (isset($admin)) { ?>
						<li class="<?php echo ($page == 'admin-page') ? 'active' : ''; ?>"><a href="admin-page.php">ADMIN PAGE</a></li>
						<li class="<?php echo ($page == 'add-restaurant') ? 'active' : ''; ?>"><a href="add-restaurant.php">ADD RESTAURANT</a></li>
						<li><a href="logout.php">LOGOUT</a></li>
                    <?php } else { ?>
                        <li><a href="login.php">LOGIN</a></li>
                    <?php } ?>
					</ul>
				</div>
			</section>

			<section class="menu">
				<div class="menu-content">
					<ul id="menu">
						<li class="<?php echo ($page == 'home') ? 'active' : ''; ?>"><a href="index.php">HOME</a></li>
						<li class="<?php echo ($page == 'restaurant-cat') ? 'active' : ''; ?>"><a href="restaurant-cat.php">RESTAURANTS</a></li>
						<li class="<?php echo ($page == 'about') ? 'active' : ''; ?>"><a href="about.php">ABOUT</a></li>
						<li class="<?php echo ($page == 'contact') ? 'active' : ''; ?>"><a href="contact.php">CONTACT</a></li>
					</ul>
				</div>
			</section>

		</header>