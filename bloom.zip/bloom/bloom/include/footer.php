<div class="clear"></div>

<section class="footer">
			<div class="margin">
				<div class="menu-footer">
					<a href="index.html">Home</a>
					
		
			</div>
		</section>

	</div>
</body>

</html>