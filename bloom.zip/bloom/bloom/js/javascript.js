function isnum(ele) {
	var r=/\D$/i;
	if(r.test(ele.value)) {
		 alert("please enter the price in number");
		 ele.value="";
		 ele.focus();
	 }
}

function isalphanum(ele) {
	var r=/\W$/i;
	if(r.test(ele.value))
	 {
		 alert("This field must contain characters letters and numbers only.");
		 ele.value="";
		 ele.focus();
	 }
}

function validateSalonForm() {
	var name = document.forms["restaurant_form"]["name"].value;
	if (name == null || name == "") {
		alert("name is required, Please fill this field.");
		return false;
	}

	var location = document.forms["restaurant_form"]["location"].value;
	if (location == null || location == "") {
		alert("Location is required, Please fill this field.");
		return false;
	}

	var open_time = document.forms["restaurant_form"]["open_time"].value;
	if (open_time == null || open_time == "") {
		alert("Open time is required, Please fill this field.");
		return false;
	}
	
	var category_id = document.forms["restaurant_form"]["category_id"].value;
	if (category_id == null || category_id == "[Select Salon Category]") {
		alert("No salon category selected or matched, Please select salon category.");
		return false;
	}
}
