<?php $page = "contact"; include("include/header.php"); ?>

		<section class="form_content" id="contact">
			<img src="img/background/contact.jpg" />

			<div class="content">
				<h1>Contact</h1>
				<hr />

				<div class="form">
					<form action="#" method="post" enctype="text/plain">
						<input name="your-name" id="your-name" placeholder="YOUR NAME" />
						<input name="your-email" id="your-email" placeholder="YOUR E-MAIL" />
						<textarea id="message" name="message" placeholder="MESSAGE"></textarea>
						<input class="button" type="submit" value="SEND" />
					</form>
				</div>
			</div>
		</section>

		<div class="clear"></div>

		<section class="footer">
			<div class="margin">
				<div class="menu-footer">
					<a href="index.html">Home</a>
		
				
			</div>
		</section>
		<?php include("include/footer.php"); ?>